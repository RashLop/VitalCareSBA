namespace ServicioUsuarios.App.Interfaces
{
    public class LoginRequestDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}