namespace ServicioUsuarios.App.Interfaces
{
    public class LoginResponseDTO
    {
        public string Token { get; set; }
    }
}