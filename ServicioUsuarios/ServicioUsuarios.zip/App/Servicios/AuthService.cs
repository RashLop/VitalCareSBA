using ServicioUsuarios.Dominio.Puertos.PuertoSalida;
using ServicioUsuarios.Infraestructura.Ayudadores;
using ServicioUsuarios.Infraestructura.Creadores;
using ServicioUsuarios.Dominio.Validadores; 

namespace ServicioUsuarios.App.Servicios
{
    public class AuthService
    {
        private readonly IUsuarioRepositorio repo;
        private readonly ITokenService token;
        private readonly LoginValidador validador;

        public AuthService(
            UsuarioRepositorioCreator creator,
            ITokenService token,
            LoginValidador validador) 
        {
            this.repo = creator.Crear();
            this.token = token;
            this.validador = validador;
        }

        public string Login(string email, string password)
        {
            // 🔥 VALIDACIÓN MIGRADA (como farmacia)
            validador.Validar(email, password);

            var usuario = repo.ObtenerPorEmail(email.Trim());

            if (usuario == null)
                throw new Exception("Usuario no existe");

            if (usuario.Activo != 1)
                throw new Exception("Usuario inactivo");

            if (!PasswordHelper.Verify(password.Trim(), usuario.PasswordHash))
                throw new Exception("Credenciales inválidas");

            return token.GenerarToken(usuario);
        }
    }
}