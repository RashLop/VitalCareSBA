using ServicioUsuarios.Dominio.Puertos.PuertoSalida;
using ServicioUsuarios.Infraestructura.Persistencia.Repositorios;

namespace ServicioUsuarios.Infraestructura.Creadores
{
    public class UsuarioRepositorioCreator
    {
        private readonly UsuarioRepositorio repo;

        public UsuarioRepositorioCreator(UsuarioRepositorio repo)
        {
            this.repo = repo;
        }

        public IUsuarioRepositorio Crear()
        {
            return repo;
        }
    }
}